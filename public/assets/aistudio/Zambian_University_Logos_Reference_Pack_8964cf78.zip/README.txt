ZAMBIAN UNIVERSITY LOGOS – REFERENCE PACKAGE

Contents:
- gallery.html: opens a visual gallery of the 9 logos (internet connection required).
- sources.csv: direct image URLs and source notes.

Important:
The images are hotlinked rather than embedded in this ZIP because direct image downloads were unavailable in this session. Open gallery.html in a browser while online to view each image, then use “Open original image” to save it. Some images come from third-party listings and may not be current official brand assets. Please verify with each university before reuse.
